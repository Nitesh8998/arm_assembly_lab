# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 02:27:06 2019

@author: browse
"""

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import numpy  as np

file = 'ds1.csv'
raw_data = open(file, 'rt')
x = np.loadtxt(raw_data, delimiter=',',usecols=range(20))
#print(x.shape)
y = np.loadtxt(file, dtype=np.str, delimiter=',',usecols=20)
#print(y.shape)

x_train, x_test, y_train, y_test=train_test_split(x, y, test_size=.3, random_state=42)
print(x_train.shape, x_test.shape)
print(y_train.shape, y_test.shape)
#print(y_test)

from sklearn.neighbors import KNeighborsClassifier
#k=1
clf=KNeighborsClassifier(n_neighbors=1)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 1")
print(classification_report(y_test, pred))

#k=100
clf=KNeighborsClassifier(n_neighbors=100)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 100")
print(classification_report(y_test, pred))

#k=142
clf=KNeighborsClassifier(n_neighbors=142)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 142")
print(classification_report(y_test, pred))

#k=200
clf=KNeighborsClassifier(n_neighbors=200)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 200")
print(classification_report(y_test, pred))

#k=500
clf=KNeighborsClassifier(n_neighbors=500)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 500")
print(classification_report(y_test, pred))

#k=1000
clf=KNeighborsClassifier(n_neighbors=1000)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 1000")
print(classification_report(y_test, pred))

#k=2000
clf=KNeighborsClassifier(n_neighbors=2000)
clf.fit(x_train, y_train)
pred=clf.predict(x_test)
print("VALUE OF K IS 2000")
print(classification_report(y_test, pred))