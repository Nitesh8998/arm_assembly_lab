# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 20:38:10 2019

@author: browse
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 19:11:22 2019

@author: manoj prabhakar d
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn import metrics

dataset = pd.read_csv('CandC.csv');
# =============================================================================
# print(dataset.shape)
# print(dataset.describe)
# print(dataset.isnull().any())
# print(dataset.isnull().sum())
# =============================================================================
dataset.fillna(dataset.mean(), inplace=True)
# =============================================================================
# print(dataset.isnull().sum())
# print(dataset.describe)
# =============================================================================
x=dataset[['state','county','community','fold','population',
         'householdsize','racepctblack','racePctWhite','racePctAsian',
         'racePctHisp','agePct12t21','agePct12t29','agePct16t24',
         'agePct65up','numbUrban','pctUrban','medIncome','pctWWage',
         'pctWFarmSelf','pctWInvInc','pctWSocSec','pctWPubAsst','pctWRetire',
         'medFamInc','perCapInc','whitePerCap','blackPerCap','indianPerCap',
         'AsianPerCap','OtherPerCap','HispPerCap','NumUnderPov','PctPopUnderPov',
         'PctLess9thGrade','PctNotHSGrad','PctBSorMore','PctUnemployed','PctEmploy',
         'PctEmplManu','PctEmplProfServ','PctOccupManu','PctOccupMgmtProf',
         'MalePctDivorce','MalePctNevMarr','FemalePctDiv','TotalPctDiv',
         'PersPerFam','PctFam2Par','PctKids2Par','PctYoungKids2Par',
         'PctTeen2Par','PctWorkMomYoungKids','PctWorkMom','NumIlleg',
         'PctIlleg','NumImmig','PctImmigRecent','PctImmigRec5','PctImmigRec8',
         'PctImmigRec10','PctRecentImmig','PctRecImmig5','PctRecImmig8',
         'PctRecImmig10','PctSpeakEnglOnly','PctNotSpeakEnglWell',
         'PctLargHouseFam','PctLargHouseOccup','PersPerOccupHous',
         'PersPerOwnOccHous','PersPerRentOccHous','PctPersOwnOccup',
         'PctPersDenseHous','PctHousLess3BR','MedNumBR','HousVacant',
         'PctHousOccup','PctHousOwnOcc','PctVacantBoarded','PctVacMore6Mos',
         'MedYrHousBuilt','PctHousNoPhone','PctWOFullPlumb','OwnOccLowQuart',
         'OwnOccMedVal','OwnOccHiQuart','RentLowQ','RentMedian','RentHighQ',
         'MedRent','MedRentPctHousInc','MedOwnCostPctInc','MedOwnCostPctIncNoMtg',
         'NumInShelters','NumStreet','PctForeignBorn','PctBornSameState',
         'PctSameHouse85','PctSameCity85','PctSameState85','LemasSwornFT',
         'LemasSwFTPerPop','LemasSwFTFieldOps','LemasSwFTFieldPerPop',
         'LemasTotalReq','LemasTotReqPerPop','PolicReqPerOffic','PolicPerPop',
         'RacialMatchCommPol','PctPolicWhite','PctPolicBlack','PctPolicHisp',
         'PctPolicAsian','PctPolicMinor','OfficAssgnDrugUnits','NumKindsDrugsSeiz',
         'PolicAveOTWorked','LandArea','PopDens','PctUsePubTrans','PolicCars',
         'PolicOperBudg','LemasPctPolicOnPatr','LemasGangUnitDeploy',
         'LemasPctOfficDrugUn','PolicBudgPerPop']].values
y=dataset['ViolentCrimesPerPop'].values

rss_avg=0;
# =============================================================================
# dataset 1
# =============================================================================
print("OUTPUT OF DATASET 1")
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=0)
regressor = LinearRegression()  
regressor.fit(x_train1, y_train1)

y_pred1 = regressor.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file=open('rss.txt', 'w')
file.write("dataset1 - rss = "+str(rss))

coeff = pd.DataFrame(regressor.coef_)
np.savetxt('coefficient-set1.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 2
# =============================================================================
print("OUTPUT OF DATASET 2")
x_train2, x_test2, y_train2, y_test2 = train_test_split(x, y, test_size=0.2, random_state=1)
regressor = LinearRegression()  
regressor.fit(x_train2, y_train2)
  
y_pred2 = regressor.predict(x_test2)
df2 = pd.DataFrame({'actual': y_test2, 'predicted': y_pred2})
df2_ = df2.head(200)
#print(df2_)

rss = np.sum(np.square(y_test2 - y_pred2))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset2 - rss = "+str(rss))

coeff = pd.DataFrame(regressor.coef_)
np.savetxt('coefficient-set2.csv', coeff)

df2_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 3
# =============================================================================
print("OUTPUT OF DATASET 3")
x_train3, x_test3, y_train3, y_test3 = train_test_split(x, y, test_size=0.2, random_state=2)
regressor = LinearRegression()  
regressor.fit(x_train3, y_train3)
  
y_pred3 = regressor.predict(x_test3)
#print(y_pred)
df3 = pd.DataFrame({'actual': y_test3, 'predicted': y_pred3})
df3_ = df3.head(200)
#print(df3_)

rss = np.sum(np.square(y_test3 - y_pred3))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset3 - rss = "+str(rss))

coeff = pd.DataFrame(regressor.coef_)
np.savetxt('coefficient-set3.csv', coeff)

df3_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 4
# =============================================================================
print("OUTPUT OF DATASET 4")
x_train4, x_test4, y_train4, y_test4 = train_test_split(x, y, test_size=0.2, random_state=3)
regressor = LinearRegression()  
regressor.fit(x_train4, y_train4)
  
y_pred4 = regressor.predict(x_test4)
#print(y_pred)
df4 = pd.DataFrame({'actual': y_test4, 'predicted': y_pred4})
df4_ = df4.head(200)
#print(df3_)

rss = np.sum(np.square(y_test4 - y_pred4))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset4 - rss = "+str(rss))

coeff = pd.DataFrame(regressor.coef_)
np.savetxt('coefficient-set4.csv', coeff)

df4_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 5
# =============================================================================
print("OUTPUT OF DATASET 5")
x_train5, x_test5, y_train5, y_test5 = train_test_split(x, y, test_size=0.2, random_state=5)
regressor = LinearRegression()  
regressor.fit(x_train5, y_train5)
  
y_pred5 = regressor.predict(x_test5)
#print(y_pred)
df5 = pd.DataFrame({'actual': y_test5, 'predicted': y_pred5})
df5_ = df5.head(200)
#print(df5_)

rss = np.sum(np.square(y_test5 - y_pred5))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset5 - rss = "+str(rss))

coeff = pd.DataFrame(regressor.coef_)
np.savetxt('coefficient-set5.csv', coeff)

df5_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

print("AVERAGE RSS: ")
print(rss_avg/5)
file.write("\naverage - rss = "+str(rss_avg/5))
file.close()