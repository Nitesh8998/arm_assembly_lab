# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 10:46:46 2019

@author: browse
"""
import numpy  as np

ftrain = 'ds2-train.csv'
raw_data = open(ftrain, 'rt')
x = np.loadtxt(raw_data, delimiter=',',usecols=range(96))
#print(x)
y = np.loadtxt(ftrain, delimiter=',',usecols=96)
#print(y)


from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression()
logmodel.fit(x, y)

ftest = 'ds2-test.csv'
raw_data = open(ftest, 'rt')
x_test = np.loadtxt(raw_data, delimiter=',',usecols=range(96))
y_test = np.loadtxt(ftest, delimiter=',',usecols=96) 
pred=logmodel.predict(x_test)
print("LOGISTIC REGRESSION WITHOUT REGULARIZATION")
from sklearn.metrics import classification_report
print(classification_report(y_test, pred))

print("LOGISTIC REGRESSION WITH REGULARIZATION - DIFFERENT C VALUES")
C = [1, .1, .001, .0001, .00001]

for c in C:
    clf = LogisticRegression(penalty='l1', C=c, solver='liblinear')
    clf.fit(x, y)
    print('C:', c)
    print(classification_report(y_test, clf.predict(x_test)))