# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 19:11:22 2019

@author: manoj prabhakar d
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn import metrics

dataset = pd.read_csv('CandC.csv');
# =============================================================================
# print(dataset.shape)
# print(dataset.describe)
# print(dataset.isnull().any())
# print(dataset.isnull().sum())
# =============================================================================
dataset.fillna(dataset.mean(), inplace=True)
# =============================================================================
# print(dataset.isnull().sum())
# print(dataset.describe)
# =============================================================================
x=dataset[['state','county','community','communityname','fold','population',
         'householdsize','racepctblack','racePctWhite','racePctAsian',
         'racePctHisp','agePct12t21','agePct12t29','agePct16t24',
         'agePct65up','numbUrban','pctUrban','medIncome','pctWWage',
         'pctWFarmSelf','pctWInvInc','pctWSocSec','pctWPubAsst','pctWRetire',
         'medFamInc','perCapInc','whitePerCap','blackPerCap','indianPerCap',
         'AsianPerCap','OtherPerCap','HispPerCap','NumUnderPov','PctPopUnderPov',
         'PctLess9thGrade','PctNotHSGrad','PctBSorMore','PctUnemployed','PctEmploy',
         'PctEmplManu','PctEmplProfServ','PctOccupManu','PctOccupMgmtProf',
         'MalePctDivorce','MalePctNevMarr','FemalePctDiv','TotalPctDiv',
         'PersPerFam','PctFam2Par','PctKids2Par','PctYoungKids2Par',
         'PctTeen2Par','PctWorkMomYoungKids','PctWorkMom','NumIlleg',
         'PctIlleg','NumImmig','PctImmigRecent','PctImmigRec5','PctImmigRec8',
         'PctImmigRec10','PctRecentImmig','PctRecImmig5','PctRecImmig8',
         'PctRecImmig10','PctSpeakEnglOnly','PctNotSpeakEnglWell',
         'PctLargHouseFam','PctLargHouseOccup','PersPerOccupHous',
         'PersPerOwnOccHous','PersPerRentOccHous','PctPersOwnOccup',
         'PctPersDenseHous','PctHousLess3BR','MedNumBR','HousVacant',
         'PctHousOccup','PctHousOwnOcc','PctVacantBoarded','PctVacMore6Mos',
         'MedYrHousBuilt','PctHousNoPhone','PctWOFullPlumb','OwnOccLowQuart',
         'OwnOccMedVal','OwnOccHiQuart','RentLowQ','RentMedian','RentHighQ',
         'MedRent','MedRentPctHousInc','MedOwnCostPctInc','MedOwnCostPctIncNoMtg',
         'NumInShelters','NumStreet','PctForeignBorn','PctBornSameState',
         'PctSameHouse85','PctSameCity85','PctSameState85','LemasSwornFT',
         'LemasSwFTPerPop','LemasSwFTFieldOps','LemasSwFTFieldPerPop',
         'LemasTotalReq','LemasTotReqPerPop','PolicReqPerOffic','PolicPerPop',
         'RacialMatchCommPol','PctPolicWhite','PctPolicBlack','PctPolicHisp',
         'PctPolicAsian','PctPolicMinor','OfficAssgnDrugUnits','NumKindsDrugsSeiz',
         'PolicAveOTWorked','LandArea','PopDens','PctUsePubTrans','PolicCars',
         'PolicOperBudg','LemasPctPolicOnPatr','LemasGangUnitDeploy',
         'LemasPctOfficDrugUn','PolicBudgPerPop','ViolentCrimesPerPop']].values
#y=dataset['ViolentCrimesPerPop'].values
  
# =============================================================================
# dataset1           
# =============================================================================
x_train, x_test = train_test_split(x, test_size=0.2, random_state=0)
np.savetxt('../../Dataset/CandC-train1.csv', x_train, fmt='%s', delimiter=',')
np.savetxt('../../Dataset/CandC-test1.csv', x_test, fmt='%s', delimiter=',')

# =============================================================================
# dataset 2
# =============================================================================
x_train, x_test = train_test_split(x, test_size=0.2, random_state=11)
np.savetxt('../../Dataset/CandC-train2.csv', x_train, fmt='%s', delimiter=',')
np.savetxt('../../Dataset/CandC-test2.csv', x_test, fmt='%s', delimiter=',')

# =============================================================================
# dataset 3
# =============================================================================
x_train, x_test = train_test_split(x, test_size=0.2, random_state=27)
np.savetxt('../../Dataset/CandC-train3.csv', x_train, fmt='%s', delimiter=',')
np.savetxt('../../Dataset/CandC-test3.csv', x_test, fmt='%s', delimiter=',')

# =============================================================================
# dataset 4
# =============================================================================
x_train, x_test = train_test_split(x, test_size=0.2, random_state=39)
np.savetxt('../../Dataset/CandC-train4.csv', x_train, fmt='%s', delimiter=',')
np.savetxt('../../Dataset/CandC-test4.csv', x_test, fmt='%s', delimiter=',')

# =============================================================================
# dataset 5
# =============================================================================
x_train, x_test = train_test_split(x, test_size=0.2, random_state=42)
np.savetxt('../../Dataset/CandC-train5.csv', x_train, fmt='%s', delimiter=',')
np.savetxt('../../Dataset/CandC-test5.csv', x_test, fmt='%s', delimiter=',')