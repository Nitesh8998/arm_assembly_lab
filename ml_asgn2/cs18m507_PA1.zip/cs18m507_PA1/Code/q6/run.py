# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 19:54:38 2019

@author: browse
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.linear_model import Ridge

dataset = pd.read_csv('CandC.csv');
# =============================================================================
# print(dataset.shape)
# print(dataset.describe)
# print(dataset.isnull().any())
# print(dataset.isnull().sum())
# =============================================================================
dataset.fillna(dataset.mean(), inplace=True)
# =============================================================================
# print(dataset.isnull().sum())
# print(dataset.describe)
# =============================================================================
x=dataset[['state','county','community','fold','population',
         'householdsize','racepctblack','racePctWhite','racePctAsian',
         'racePctHisp','agePct12t21','agePct12t29','agePct16t24',
         'agePct65up','numbUrban','pctUrban','medIncome','pctWWage',
         'pctWFarmSelf','pctWInvInc','pctWSocSec','pctWPubAsst','pctWRetire',
         'medFamInc','perCapInc','whitePerCap','blackPerCap','indianPerCap',
         'AsianPerCap','OtherPerCap','HispPerCap','NumUnderPov','PctPopUnderPov',
         'PctLess9thGrade','PctNotHSGrad','PctBSorMore','PctUnemployed','PctEmploy',
         'PctEmplManu','PctEmplProfServ','PctOccupManu','PctOccupMgmtProf',
         'MalePctDivorce','MalePctNevMarr','FemalePctDiv','TotalPctDiv',
         'PersPerFam','PctFam2Par','PctKids2Par','PctYoungKids2Par',
         'PctTeen2Par','PctWorkMomYoungKids','PctWorkMom','NumIlleg',
         'PctIlleg','NumImmig','PctImmigRecent','PctImmigRec5','PctImmigRec8',
         'PctImmigRec10','PctRecentImmig','PctRecImmig5','PctRecImmig8',
         'PctRecImmig10','PctSpeakEnglOnly','PctNotSpeakEnglWell',
         'PctLargHouseFam','PctLargHouseOccup','PersPerOccupHous',
         'PersPerOwnOccHous','PersPerRentOccHous','PctPersOwnOccup',
         'PctPersDenseHous','PctHousLess3BR','MedNumBR','HousVacant',
         'PctHousOccup','PctHousOwnOcc','PctVacantBoarded','PctVacMore6Mos',
         'MedYrHousBuilt','PctHousNoPhone','PctWOFullPlumb','OwnOccLowQuart',
         'OwnOccMedVal','OwnOccHiQuart','RentLowQ','RentMedian','RentHighQ',
         'MedRent','MedRentPctHousInc','MedOwnCostPctInc','MedOwnCostPctIncNoMtg',
         'NumInShelters','NumStreet','PctForeignBorn','PctBornSameState',
         'PctSameHouse85','PctSameCity85','PctSameState85','LemasSwornFT',
         'LemasSwFTPerPop','LemasSwFTFieldOps','LemasSwFTFieldPerPop',
         'LemasTotalReq','LemasTotReqPerPop','PolicReqPerOffic','PolicPerPop',
         'RacialMatchCommPol','PctPolicWhite','PctPolicBlack','PctPolicHisp',
         'PctPolicAsian','PctPolicMinor','OfficAssgnDrugUnits','NumKindsDrugsSeiz',
         'PolicAveOTWorked','LandArea','PopDens','PctUsePubTrans','PolicCars',
         'PolicOperBudg','LemasPctPolicOnPatr','LemasGangUnitDeploy',
         'LemasPctOfficDrugUn','PolicBudgPerPop']].values
y=dataset['ViolentCrimesPerPop'].values
  
rss_avg=0;
# =============================================================================
# dataset 1 and alpha=.01
# =============================================================================
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=0)

rr01 = Ridge(alpha=0.01)
rr01.fit(x_train1, y_train1)
  
y_pred1 = rr01.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file=open('rss.txt', 'w')
file.write("dataset1 - rss = "+str(rss))

coeff = pd.DataFrame(rr01.coef_)
np.savetxt('coefficient-set1.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 2 and alpha=1
# =============================================================================
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=1)

rr1 = Ridge(alpha=1)
rr1.fit(x_train1, y_train1)
  
y_pred1 = rr1.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset2 - rss = "+str(rss))

coeff = pd.DataFrame(rr1.coef_)
np.savetxt('coefficient-set2.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 3 and alpha=10
# =============================================================================
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=2)

rr10 = Ridge(alpha=10)
rr10.fit(x_train1, y_train1)
  
y_pred1 = rr10.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset3 - rss = "+str(rss))

coeff = pd.DataFrame(rr10.coef_)
np.savetxt('coefficient-set3.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 4 and alpha=100
# =============================================================================
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=3)

rr100 = Ridge(alpha=100)
rr100.fit(x_train1, y_train1)
  
y_pred1 = rr100.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset4 - rss = "+str(rss))

coeff = pd.DataFrame(rr100.coef_)
np.savetxt('coefficient-set4.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

# =============================================================================
# dataset 5 and alpha=200
# =============================================================================
x_train1, x_test1, y_train1, y_test1 = train_test_split(x, y, test_size=0.2, random_state=5)

rr200 = Ridge(alpha=200)
rr200.fit(x_train1, y_train1)
  
y_pred1 = rr200.predict(x_test1)
#print(y_pred)
df1 = pd.DataFrame({'actual': y_test1, 'predicted': y_pred1})
df1_ = df1.head(200)
#print(df1_)

rss = np.sum(np.square(y_test1 - y_pred1))
print("RSS=")
print(rss)
rss_avg=rss_avg+rss
file.write("\ndataset5 - rss = "+str(rss))

coeff = pd.DataFrame(rr200.coef_)
np.savetxt('coefficient-set5.csv', coeff)

df1_.plot(kind='line',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

print("AVERAGE RSS: ")
print(rss_avg/5)
file.write("\naverage - rss = "+str(rss_avg/5))
file.close()