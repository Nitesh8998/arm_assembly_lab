# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 00:48:41 2019

@author: browse
"""

import numpy as np

features=20
n=2000

def rand_mean(n):
    return np.random.rand(n)

def rand_cov(n):
    a=np.random.rand(n,n)
    cov=np.dot(a,a.transpose())
    return cov

def eye_cov(n):
    return np.eye(n)

mean_0=rand_mean(features)
mean_1=mean_0+10*rand_mean(features)

cov=rand_cov(features)

import matplotlib.pyplot as plot
#import matplotlib.cm as cm

class_0=np.random.multivariate_normal(mean_0,cov,n)
temp=np.zeros((n,21))
temp[:,:-1] = class_0
class_0=temp

class_1=np.random.multivariate_normal(mean_1,cov,n)
temp=np.ones((n,21))
temp[:,:-1] = class_1
class_1=temp

np.savetxt("class0.csv", class_0, fmt='%10.5f', delimiter=',')
np.savetxt("class1.csv", class_1, fmt='%10.5f', delimiter=',')

f1 = open("class0.csv")
f1_contents = f1.read()
f1.close()

f2 = open("class1.csv")
f2_contents = f2.read()
f2.close()

f3 = open("ds1.csv", "w") # open in `w` mode to write
f3.write(f1_contents) # concatenate the contents
f3.write(f2_contents)
f3.close()

plot.scatter(class_0[:,0], class_0[:,1], color='red')
plot.scatter(class_1[:,0], class_1[:,1], color='blue')
plot.show()

file = 'ds1.csv'
raw_data = open(file, 'rt')
x = np.loadtxt(raw_data, delimiter=',',usecols=range(21))
print(x.shape)

from sklearn.model_selection import train_test_split
x_train, x_test=train_test_split(x, test_size=.3, random_state=42)
print(x_train.shape, x_test.shape)
np.savetxt('../../Dataset/DS1-train.csv', x_train, delimiter=',')
np.savetxt('../../Dataset/DS1-test.csv', x_test, delimiter=',')