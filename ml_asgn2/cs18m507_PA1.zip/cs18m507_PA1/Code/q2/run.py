# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 18:34:02 2019

@author: browse
"""

import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn import metrics

dataset = pd.read_csv('ds1-lr.csv');
# =============================================================================
# print(dataset.shape)
# print(dataset.describe)
# print(dataset.isnull().any())
# =============================================================================
x=dataset[['x1','x2','x3','x4','x5','x6','x7','x8','x9','x10','x11','x12',
           'x13','x14','x15','x16','x17','x18','x19','x20']].values
y=dataset['y'].values

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)
regressor = LinearRegression()  
regressor.fit(x_train, y_train)


y_pred = regressor.predict(x_test)
for i in range(len(y_pred)):
    if (y_pred[i] > .5):
        y_pred[i]=1
    else:
        y_pred[i]=0
print(y_test)
print(y_pred)
# =============================================================================
# df = pd.DataFrame({'actual': y_test, 'predicted': y_pred})
# df1 = df.head(250)
# for ind in df1.index:
#     if (df1['predicted'][ind] > .5):
#         df1['predicted'][ind]=1
#     else:
#         df1['predicted'][ind]=0
# =============================================================================

from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))
# =============================================================================
# print(df1)
# =============================================================================

# =============================================================================
# df1.plot(kind='bar',figsize=(10,8))
# plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
# plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
# plt.show()
# =============================================================================
