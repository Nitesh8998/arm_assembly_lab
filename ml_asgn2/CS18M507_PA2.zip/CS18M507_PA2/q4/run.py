# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 11:43:03 2019

@author: browse
"""
import time
def file_to_tuple(f, closeFile):
    list_tuple=[];
    for x in f:
        _tuple=x.split();
        if len(_tuple)<2:
            continue
        list_tuple.append((int(_tuple[0]),int(_tuple[1])));
    if closeFile: f.close();
    return list_tuple;


def permuted_row_index(x, c1, c2, c3):
    return (c1*x + c2)%c3


def swap_key_value(_tuple):
    return (_tuple[1],_tuple[0])


def value_only_from_tuple(_tuple):
    return _tuple[1]


def group_by_value(list_of_tuple1, list_of_tuple2):
    grouped_tuple_list=[]
    index=-1
    for _tuple in list_of_tuple1:
        for i in range(len(list_of_tuple2)):
            if _tuple[1] in list_of_tuple2[i]:
                _tuple=tuple(set(_tuple + list_of_tuple2[i]))
                index=i
                break
        grouped_tuple_list.append(_tuple)
        if index!=-1:
            list_of_tuple2.pop(index)
            index=-1
    grouped_tuple_list.extend(list_of_tuple2)          
    return grouped_tuple_list


def minhashing(list_of_tuple):
    key=list_of_tuple[0][0]
    minhash=c;
    list_of_minhash=[]
    list_of_value=list(map(value_only_from_tuple, list_of_tuple))
    
    for i in random_a_b:
        const1_hash=i[0]
        const2_hash=i[1]
        for x in list_of_value:
            temp=permuted_row_index(x, const1_hash, const2_hash, c);
            if minhash>temp:
                 minhash=temp
        list_of_minhash.append(minhash)
    li= list(map(lambda x:(key,x), list_of_minhash))
    return li
        


def jaccard_similarity(doc1,doc2):
   val_grpd_tuple_list=group_by_value(doc1,doc2)
#   print(val_grpd_tuple_list)
   union_cnt=len(val_grpd_tuple_list)
   print(union_cnt)
   intersection_cnt=len(list(x for x in val_grpd_tuple_list if len(x)>2))
   print(intersection_cnt)
   return (intersection_cnt/union_cnt)


def exact_value_match(list_of_tuple1, list_of_tuple2):
    counter=0
    for (v1,v2) in zip(list_of_tuple1, list_of_tuple2):
        if v1[1]==v2[1]:
            counter+=1
    return counter
            

def jaccard_similarity_minhashed(doc1,doc2):
   union_cnt=len(doc1)
   print(union_cnt)
   intersection_cnt=exact_value_match(doc1,doc2)
   print(intersection_cnt)
   return (intersection_cnt/union_cnt)
                   

def hash_to_buckets(r, b, signature_one, doc_id):
    if r*b!=len(signature_one):
        print("r*b is not equal to the length of signatures")
        return
    temp_hash=""     #to string of list output
    index=-1;    #to count the index of list_of_lists
    for i in range(1,r*b+1):
        temp_hash+="/"+str(signature_one.pop(0))
#        print(temp_hash)
        if i%r==0:
            index+=1
            if len(list_of_dicts)<index+1:
                list_of_dicts.insert(index, {})
            temp_hash_table=list_of_dicts[index]
            temp_li=[]
            try:
                temp_li=temp_hash_table[temp_hash]
            except:
                pass
            temp_li.append(doc_id)
            temp_hash_table[temp_hash]=temp_li
            list_of_dicts.pop(index)
            list_of_dicts.insert(index, temp_hash_table)
            temp_hash=""

                   
def lsh(r, b_of_r):
    f1=open("..\docword.enron", "r")
#    f1=open("..\docword.sample", "r")
    f1.readline()
    f1.readline()
    f1.readline()
    old=-1
    run=1
    ff0=0
    ff1=1
    print("COMPUTATION IN PROGRESS.........")
    while(run):
        i=0
        if ff0!=0:
            list_tuple=[(ff0,ff1)]
        else:
            list_tuple=[]
        while(run):
            i+=1
            try:
                ff=f1.readline().split()
                if int(ff[0]) != old:
                    if i==1:
                        list_tuple.append((int(ff[0]),int(ff[1])));
                        old=int(ff[0])
                    else:
                        old=int(ff[0])
                        ff0=int(ff[0])
                        ff1=int(ff[1])
                        break
                else:
                    list_tuple.append((int(ff[0]),int(ff[1])));
            except:
                print("end of file")
                run=0
        
        doc=minhashing(list_tuple)
        hash_to_buckets(r, b_of_r, list(map(value_only_from_tuple, doc)), list_tuple[0][0])
    
    
c=28102
list_of_dicts=[]
# =============================================================================
# f=open("docword.enron", "r");
# f=open("docword.sample", "r")
# no_of_docs=int(f.readline())
# f.readline()
# f.readline()
# 
# print(no_of_docs)
# print("enter the value of k, keep the value less than 5:")
# input_k=input()
# try:
#     k=int(input_k)
# except:
#     raise Exception("value of k should be a number")
# =============================================================================
f_out=open("out.txt", "a+")
print("COMPUTATION STARTED AT: ",time.localtime())
f_out.write("COMPUTATION STARTED AT: ")
f_out.write(str(time.localtime())+"\r\n")
import random
random_a_b=[]
for i in range(0,100):
#    li.append((random.random()*i*1000,random.random()*i*1000))
    random_a_b.append((random.randint(11111,99999),random.randint(11111,99999)))

# =============================================================================
# task1()
# findingKNN(k)
# =============================================================================
lsh(100,1)
print("COMPUTATION COMPLETED AT: ",time.localtime())
f_out.write("COMPUTATION COMPLETED AT: ")
f_out.write(str(time.localtime())+"\r\n")
#print(list_of_dicts)
b_count=1
for _dict in list_of_dicts:
    print("PRINTING DOC IDS IN SAME BUCKET FOR B=", b_count)
    f_out.write("PRINTING DOC IDS IN SAME BUCKET FOR B=")
    f_out.write(str(b_count)+"\r\n")
    _list=_dict.items()
    for _tuple in _list:
        if len(_tuple[1])>1:
            print(_tuple[1])
            f_out.writelines(str(_tuple[1])+"\r\n")
    b_count+=1
f_out.close()